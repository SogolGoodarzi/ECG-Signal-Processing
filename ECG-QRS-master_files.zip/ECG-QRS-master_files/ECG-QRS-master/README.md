# ECG-QRS
Disease detection through QRS complex interval in ECG signals. (digital signal processing's project)

For details: 

Read this article https://github.com/mohammadzainabbas/ECG-QRS-/blob/master/DSP-Project-Description.pdf
